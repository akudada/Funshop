export const REACT_APP_BASE_URL = 'http://192.168.100.26:3001';
